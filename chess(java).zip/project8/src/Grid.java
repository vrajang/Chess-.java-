//class which creates the grid

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;


public class Grid {

    /**
     * The radius of the circle
     */
    double radius = 10.0;

    /**
     * The x-coordinate of the center
     */
    double x =0;

    /**
     * The y-coordinate of the center
     */
    double y = 0;


    /**
     * Moves the circle to a new location.
     *
     * @param newX The new x location.
     * @param newY The new y location.
     */
    void setLocation(double newX, double newY) {
        x = newX;
        y = newY;
    }

    /**
     * Test whether two circles are equal.
     * @param other The other circle.
     * @return True if the location and radius are the same.
     */
    boolean equals(Grid other) {
        return (x == other.x && y == other.y && radius == other.radius);
    }

    /**
     * Draws the circle on a GraphicsContext object.
     *
     * @param gc The GraphicsContext to draw on.
     */
    void draw(GraphicsContext gc) {
        int x=0;
        int y=0;
        int y2=300;
        int x2=300;
        //horizonal lines
        for (int i=0;i<10;i++) {
            x=x+30;
            //y=y+30;
            y2=300+30;
            gc.setStroke(Color.BLACK);
            gc.setLineWidth(radius / 4);
            gc.strokeLine(30,30,30,360);
            gc.strokeLine(x+30, y+30, x+30, y2+30);
        }

        //vertical lines
        for (int i=0;i<10;i++) {
            x=0;
            y=y+30;

            gc.setStroke(Color.BLACK);
            gc.setLineWidth(radius / 4);
            gc.strokeLine(30,30,330,30);
            gc.strokeLine(x+30, y+30, x2+30, y+30);
            gc.strokeLine(30,360,330,360);
        }
    }
}
