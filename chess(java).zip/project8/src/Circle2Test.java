//test to check the game
//vrajang shah (000826893)
import java.util.ArrayList;

import javafx.scene.Group;
import javafx.scene.control.TextField;
import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;

import javafx.scene.input.MouseEvent;

import javafx.scene.paint.Color;

import javafx.stage.Stage;




//Main class
public class Circle2Test extends Application {
    int flag = 0;
    boolean primaryKey = false;
    GraphicsContext gc;
    Shape shape;
    Shape selectShape ;
    Canvas c;
    ArrayList<Shape> shapeList = new ArrayList<Shape>();
    ColorPicker colorPickerOne = null, colorPickerTwo = null;
    TextField lineWidth;
    private double x1, x2, y1, y2, selectX, selectY2, selectX2, selectY;
    //Label label;
    Button buttontoadd;

    //event to control the mouse click

    private void PressHandler(MouseEvent me) {

        try {

            int a = Integer.parseInt(lineWidth.getText());// get line width
            // get cordinates of press event
            x1 = me.getX();
            y1 = me.getY();
            // chack if press done by right click or left click

            if (me.isPrimaryButtonDown()) {
                primaryKey = true;
                // call appropriate class using polymorphism
                shape = new Circle(flag);
            }

            else if(shapeList.isEmpty()){
                new Alert(Alert.AlertType.WARNING, "Please draw object with left click").showAndWait();
            }




        }
        catch (NumberFormatException e) {
            // handle exception and print error
            new Alert(Alert.AlertType.WARNING, "Please give the value of stroke").showAndWait();

        }

    }

    //Circle Handler to call the circle class
    private void CircleHandler(MouseEvent me) {
        flag = 1;


    }


    //reate your components and the model and add event
    //* handlers.
    /*
     * @param stage The main stage
     * @throws Exception
     */
    @Override
    public void start(Stage stage) throws Exception {
        //Pane root = new Pane();
        Group root = new Group();
        Scene scene = new Scene(root);
        Canvas canvas = new Canvas(800, 600); // Set canvas Size in Pixels
        stage.setTitle("GRID GAME"); // Set window title
        root.getChildren().add(canvas);
        stage.setScene(scene);


        colorPickerOne =new ColorPicker(Color.BLACK);
        buttontoadd = new Button("circle");
        c = new Canvas(1000, 500);
        gc = c.getGraphicsContext2D();
        //to add or remove the varibles on the canvas
        root.getChildren().addAll(c,buttontoadd,colorPickerOne);
        gc.setFill(Color.LIGHTGREEN);
        gc.fillRect(0, 0, 1000, 500);
        gc.setFill(Color.BLACK);
        gc.fillRect(300, 500, 2, 200);
        buttontoadd.relocate(20, 530);
        buttontoadd.setPrefWidth(100);
        buttontoadd.setPrefHeight(50);
        colorPickerOne.relocate(380, 530);
        colorPickerOne.setPrefWidth(100);
        colorPickerOne.setPrefHeight(50);
        c.addEventHandler(MouseEvent.MOUSE_PRESSED, this::PressHandler);
        // Calling the appropriate class of mousehandler
        buttontoadd.addEventHandler(MouseEvent.MOUSE_PRESSED, this::CircleHandler);
        buttontoadd.setOnMouseClicked(this::PressHandler);

        // calls the grid class and creates the grid
        Grid c = new Grid();
        c.draw(gc);
        stage.show();
    }

    /**
     * The actual main method that launches the app.
     *
     * @param args unused
     */
    public static void main(String[] args) {
        launch(args);
    }
}
